import styled, { keyframes } from "styled-components";

import { FlexBetween } from "../Common.styles";

export const Wrapper = styled.div`
  width: 100%;
  max-width: 800px;
  margin: 0 auto;
  padding: 40px 20px;
`;

export const StepContainer = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  margin-bottom: 50px;
`;

export const Step = styled.div<{ $active: boolean }>`
  display: flex;
  align-items: center;
  gap: 8px;
`;

export const StepNumber = styled.div<{ $active?: boolean }>`
  width: 24px;
  height: 24px;
  border-radius: 50%;
  background-color: ${(props) => (props.$active ? "#000" : "#f0f0f0")};
  color: ${(props) => (props.$active ? "#fff" : "#999")};
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 13px;
  font-weight: bold;
`;

export const StepText = styled.span<{ $active: boolean }>`
  font-size: 16px;
  font-weight: ${(props) => (props.$active ? "bold" : "normal")};
  color: ${(props) => (props.$active ? "#000" : "#999")};
  text-decoration: ${(props) => (props.$active ? "underline" : "none")};
  text-underline-offset: 4px;
`;

export const StepDivider = styled.div`
  width: 40px;
  height: 1px;
  border-bottom: 1px dashed #ccc;
  margin: 0 15px;
`;

export const CheckAllWrapper = styled.div`
  border-top: 1px solid #e5e5e5;
  border-bottom: 1px solid #e5e5e5;
  padding: 20px 0;
  margin-bottom: 30px;
`;

export const CheckboxLabel = styled.label`
  display: flex;
  align-items: center;
  gap: 10px;
  cursor: pointer;
`;

/* 커스텀 사각 체크박스 디자인 */
export const CheckboxInput = styled.input`
  appearance: none;
  width: 20px;
  height: 20px;
  flex-shrink: 0;
  border: 1px solid #d1d5db;
  border-radius: 2px;
  background-color: #fff;
  cursor: pointer;
  position: relative;

  &::after {
    content: "✓";
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    color: #d1d5db;
    font-size: 14px;
    transition: color 0.2s ease;
  }

  &:checked {
    border-color: #000;
  }

  /* 체크시 나타나는 V 마크 */
  &:checked::after {
    content: "✓";
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    color: #000;
    font-size: 14px;
    transition: color 0.2s ease;
  }

  &:-webkit-autofill,
  &:-webkit-autofill:hover,
  &:-webkit-autofill:focus {
    -webkit-box-shadow: 0 0 0 30px #fff inset !important; /* 배경을 흰색으로 고정 */
    -webkit-text-fill-color: #000 !important;
  }
`;

export const CheckAllText = styled.span`
  font-size: 16px;
  font-weight: bold;
  color: #000;
  margin-bottom: 3px;
`;

export const TermSection = styled.div`
  margin-bottom: 30px;
`;

export const TermHeader = styled.div`
  ${FlexBetween}
  margin-bottom: 15px;
`;

export const TermTitle = styled.span`
  font-size: 15px;
  color: #444;
  margin-bottom: 3px;
`;

export const ToggleButton = styled.button`
  background: none;
  border: none;
  color: #666;
  font-size: 14px;
  cursor: pointer;
  display: flex;
  align-items: center;
  gap: 4px;
`;

export const TermContentBox = styled.div<{ $isOpen: boolean }>`
  display: ${(props) => (props.$isOpen ? "block" : "none")};
  width: 100%;
  height: 140px;
  overflow-y: auto;
  border: 1px solid #e5e5e5;
  padding: 20px;
  font-size: 13px;
  color: #666;
  background-color: #fff;
  line-height: 1.6;
  white-space: pre-wrap;
`;

export const ButtonGroup = styled.div`
  display: flex;
  justify-content: center;
  gap: 10px;
  margin-top: 60px;
`;

export const Button = styled.button<{ $variant: "outline" | "solid" }>`
  width: 180px;
  height: 54px;
  font-size: 16px;
  font-weight: bold;
  border-radius: 4px;
  cursor: pointer;
  transition: all 0.2s;
  background-color: ${(props) =>
    props.$variant === "outline" ? "#fff" : "#000"};
  border: 1px solid;
  color: ${(props) => (props.$variant === "outline" ? "#000" : "#fff")};

  &:hover {
    background-color: ${(props) =>
      props.$variant === "outline" ? "#f9f9f9" : "#333"};
  }

  @media (max-width: 480px) {
    width: 100%;
  }
`;

//회원가입 폼(step 2)
export const PageTitle = styled.h2`
  text-align: center;
  font-size: 28px;
  font-weight: 900;
  margin-bottom: 40px;
`;

export const FormContainer = styled.div`
  width: 100%;
  display: flex;
  flex-direction: column;
  gap: 24px;
  margin-top: 20px;
`;

export const FormGroup = styled.div`
  display: flex;
  flex-direction: column;
  gap: 10px;
`;

export const Label = styled.label`
  font-size: 15px;
  font-weight: bold;
  color: #111;
`;

export const Input = styled.input<{ $isError?: boolean; $isSuccess?: boolean }>`
  width: 100%;
  height: 50px;
  padding: 0 15px;
  border: 1px solid
    ${(props) =>
      props.$isError ? "#ff4d4f" : props.$isSuccess ? "#27ae60" : "#e5e5e5"};
  font-size: 15px;
  outline: none;

  transition: border-color 0.2s ease;

  &::placeholder {
    color: #aaa;
  }

  &:focus {
    border-color: ${(props) =>
      props.$isError ? "#ff4d4f" : props.$isSuccess ? "#27ae60" : "#333333"};
  }
`;

export const Message = styled.p<{ $isError: boolean }>`
  font-size: 13px;
  margin-top: -4px;
  margin-bottom: 12px;
  /* $isError 값에 따라 빨간색 또는 초록색으로 변경 */
  color: ${(props) => (props.$isError ? "#ff4d4f" : "#27ae60")};
`;

export const EmailWrapper = styled.div`
  display: flex;
  gap: 10px;

  @media (max-width: 480px) {
    flex-direction: column;
  }
`;

export const Select = styled.select`
  width: 100%;
  height: 50px;
  padding: 0 15px;
  border: 1px solid #e5e5e5;
  font-size: 15px;
  color: #555;
  outline: none;
  background-color: #fff;
`;

export const SubCheckboxLabel = styled.label`
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 14px;
  color: #333333;
  cursor: pointer;
  margin-top: 5px;
`;

export const RadioWrapper = styled.div`
  display: flex;
  align-items: center;
  gap: 30px;
  height: 50px;
`;

export const RadioLabel = styled.label`
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 15px;
  font-weight: bold;
  cursor: pointer;
`;

export const RadioInput = styled.input`
  appearance: none;
  width: 20px;
  height: 20px;
  border: 1px solid #ccc;
  border-radius: 50%;
  outline: none;
  cursor: pointer;
  position: relative;

  &:checked {
    border-color: #111;
  }
  &:checked::after {
    content: "";
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    width: 10px;
    height: 10px;
    border-radius: 50%;
    background-color: #111;
  }
`;

export const Container = styled.div``;

export const Title = styled.h2``;

export const Section = styled.div<{ $marginBottom: string }>``;

export const SectionTitle = styled.h3``;

export const TermsBox = styled.div<{ $bg: string }>``;

export const Checkbox = styled.input<{ $isLarge?: boolean }>``;

export const TotalAgreeText = styled.span``;

export const AgreeText = styled.span``;

export const Dflex = styled.div`
  display: flex;
  gap: 10px;
  margin-bottom: 10px;
`;
export const ModalBG = styled.div`
  position: fixed;
  background-color: rgba(0, 0, 0, 0.3);
  z-index: 999999;
  left: 0;
  top: 0;
  width: 100%;
  height: 100%;
`;
export const ModalContent = styled.div`
  position: fixed;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  width: 400px;
  height: 500px;
  z-index: 9999999;
  background-color: #fff;
`;

export const RightBtn = styled.div`
  display: flex;
  justify-content: flex-end;
  padding: 5px;

  button {
    background-color: transparent;
    border: none;
  }
`;

//슬라이더
export const SliderSection = styled.section`
  background-color: #ffe5f0;
  padding: 60px 20px;
  overflow: hidden;
`;

export const SliderInner = styled.div`
  max-width: 1200px;
  margin: 0 auto;
`;

export const SliderHeader = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: flex-end;
  margin-bottom: 30px;
`;

export const SliderTitleGroup = styled.div`
  display: flex;
  flex-direction: column;
`;

export const SliderMainTitle = styled.h2`
  font-size: 32px;
  font-weight: 900;
  color: #111;
  margin: 0;
`;

export const SliderSubTitle = styled.p`
  font-size: 18px;
  color: #888;
  margin: 5px 0 0 0;
`;

export const SliderControls = styled.div`
  display: flex;
  align-items: center;
  gap: 10px;
`;

export const SliderViewMoreBtn = styled.button`
  border: 1px solid #111;
  background: transparent;
  border-radius: 20px;
  padding: 8px 16px;
  font-size: 14px;
  font-weight: 600;
  cursor: pointer;

  &:hover {
    background-color: #111;
    color: #fff;
  }
`;

export const SliderArrowBtn = styled.button`
  width: 36px;
  height: 36px;
  border-radius: 50%;
  background-color: #111;
  color: #fff;
  border: none;
  font-size: 16px;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;

  &:hover {
    background-color: #333;
  }
`;

export const SelfieSliderWrapper = styled.div`
  display: flex;
  gap: 20px;
  overflow-x: auto;
  scroll-behavior: smooth;
  padding-bottom: 20px;

  &::-webkit-scrollbar {
    display: none;
  }

  -ms-overflow-style: none;
  scrollbar-width: none;
`;

export const SelfieCard = styled.div`
  min-width: 240px;
  height: 340px;
  border-radius: 20px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
  cursor: pointer;

  img {
    width: 100%;
    height: 100%;
    object-fit: cover;
  }
`;

export const SelfieCardOverlay = styled.div`
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: linear-gradient(
    to bottom,
    rgba(0, 0, 0, 0.3) 0%,
    rgba(0, 0, 0, 0) 30%,
    rgba(0, 0, 0, 0) 60%,
    rgba(0, 0, 0, 0.6) 100%
  );
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  padding: 20px;
`;

export const SelfieLikeBadge = styled.div`
  color: #fff;
  font-size: 14px;
  display: flex;
  align-items: center;
  gap: 5px;

  span {
    color: #ff1493;
    font-size: 18px;
  }
`;

export const SelfieViewCount = styled.div`
  color: #fff;
  font-size: 15px;
  font-weight: 700;

  span {
    display: block;
    font-size: 12px;
    font-weight: 400;
    color: #ccc;
    margin-top: 4px;
  }
`;

export const LinkGroup = styled.div`
  text-align: center;
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
`;

export const StyledLink = styled.a`
  display: block;
  width: fit-content;
  margin: 0 auto;
  font-size: 0.8rem;
  color: #000;
  text-decoration: none;

  cursor: pointer;

  &:hover {
    text-decoration: underline;
    color: #333;
  }
`;
