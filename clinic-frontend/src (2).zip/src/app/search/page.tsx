import { Suspense } from "react";

import SearchResultsClient from "@/components/search/SearchResultsClient";

export const metadata = {
  title: "통합검색 | AHNS",
  description: "AHNS의 시술 정보, 자주 묻는 질문, 이벤트와 영상을 검색합니다.",
};

export default function SearchPage() {
  return (
    <Suspense
      fallback={
        <main style={{ padding: "160px 24px" }}>
          검색 화면을 준비하고 있습니다.
        </main>
      }
    >
      <SearchResultsClient />
    </Suspense>
  );
}
