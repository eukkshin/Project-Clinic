"use client";

import { useRouter } from "next/navigation";
import { useCallback } from "react";

import { normalizeLocale } from "@/i18n/config";

export function useChangeLocale() {
  const router = useRouter();

  return useCallback(
    async (value: string) => {
      const locale = normalizeLocale(value);
      if (!locale) throw new Error(`Unsupported language selection: ${value}`);

      const response = await fetch("/api/locale", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "same-origin",
        cache: "no-store",
        body: JSON.stringify({ locale }),
      });
      if (!response.ok) throw new Error("Failed to save the selected language");

      // Re-fetches Server Components / NextIntlClientProvider with the new cookie.
      router.refresh();
    },
    [router],
  );
}
