"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { FormEvent, useCallback, useEffect, useState } from "react";

import {
  accountApi,
  AccountPreferences,
  AccountProfile,
} from "@/lib/mypage/account-settings-api";
import * as S from "@/styles/mypage/AccountSettings.styles";
import * as M from "@/styles/mypage/MyPage.styles";

type Tab = "profile" | "password" | "preferences";
const menus = [
  { href: "/mypage", label: "내 정보" },
  { href: "/mypage/reservations", label: "예약 내역" },
  { href: "/mypage/consultations", label: "내 상담 내역" },
  { href: "/mypage/accountsettings", label: "계정 설정" },
];
function showDate(value?: string | null) {
  if (!value) return "정보 없음";
  const d = new Date(value);
  return Number.isNaN(d.getTime())
    ? value
    : new Intl.DateTimeFormat("ko-KR", {
        year: "numeric",
        month: "2-digit",
        day: "2-digit",
      }).format(d);
}
function errorText(e: unknown) {
  return e instanceof Error ? e.message : "요청을 완료하지 못했습니다.";
}
function newPasswordValid(value: string) {
  return value.length >= 10 && new TextEncoder().encode(value).length <= 72;
}

export default function AccountSettingsClient() {
  const router = useRouter();
  const [tab, setTab] = useState<Tab>("profile");
  const [profile, setProfile] = useState<AccountProfile | null>(null);
  const [savedPreferences, setSavedPreferences] =
    useState<AccountPreferences | null>(null);
  const [draftPreferences, setDraftPreferences] = useState<AccountPreferences>({
    mailAgreed: false,
    snsAgreed: false,
  });
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState("");
  const [prefError, setPrefError] = useState("");
  const [prefSuccess, setPrefSuccess] = useState("");
  const [savingPrefs, setSavingPrefs] = useState(false);
  const [currentEmailPassword, setCurrentEmailPassword] = useState("");
  const [newEmail, setNewEmail] = useState("");
  const [emailBusy, setEmailBusy] = useState(false);
  const [emailError, setEmailError] = useState("");
  const [emailSuccess, setEmailSuccess] = useState("");
  const [confirmToken, setConfirmToken] = useState("");
  const [confirmBusy, setConfirmBusy] = useState(false);
  const [oldPassword, setOldPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [passwordBusy, setPasswordBusy] = useState(false);
  const [passwordError, setPasswordError] = useState("");

  const load = useCallback(async (signal?: AbortSignal) => {
    setLoading(true);
    setLoadError("");
    try {
      const [p, pref] = await Promise.all([
        accountApi.getProfile(signal),
        accountApi.getPreferences(signal),
      ]);
      if (signal?.aborted) return;
      setProfile(p);
      setSavedPreferences(pref);
      setDraftPreferences(pref);
    } catch (e) {
      if (!signal?.aborted) setLoadError(errorText(e));
    } finally {
      if (!signal?.aborted) setLoading(false);
    }
  }, []);

  useEffect(() => {
    const controller = new AbortController();
    void load(controller.signal);
    // 이메일 인증 링크의 일회성 토큰을 화면 상태로만 보관하고 URL에서는 즉시 제거.
    const params = new URLSearchParams(window.location.search);
    const token = params.get("emailToken");
    if (token) {
      setConfirmToken(token);
      setTab("profile");
      const clean = new URL(window.location.href);
      clean.searchParams.delete("emailToken");
      window.history.replaceState(
        window.history.state,
        "",
        clean.pathname + clean.search + clean.hash,
      );
    }
    return () => controller.abort();
  }, [load]);

  async function submitEmail(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (emailBusy) return;
    setEmailError("");
    setEmailSuccess("");
    const normalizedEmail = newEmail.trim().toLowerCase();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(normalizedEmail)) {
      setEmailError("새 이메일 주소를 올바르게 입력해 주세요.");
      return;
    }
    if (!currentEmailPassword) {
      setEmailError("현재 비밀번호를 입력해 주세요.");
      return;
    }
    setEmailBusy(true);
    try {
      await accountApi.requestEmailChange(
        currentEmailPassword,
        normalizedEmail,
      );
      setEmailSuccess(
        "새 이메일로 15분 유효한 인증 링크를 발송했습니다. 링크를 열어 변경을 확정해 주세요.",
      );
      setCurrentEmailPassword("");
      setNewEmail("");
    } catch (error) {
      setEmailError(errorText(error));
    } finally {
      setEmailBusy(false);
    }
  }

  async function confirmEmail() {
    if (!confirmToken || confirmBusy) return;
    setEmailError("");
    setEmailSuccess("");
    setConfirmBusy(true);
    try {
      const result = await accountApi.confirmEmailChange(confirmToken);
      setConfirmToken("");
      setEmailSuccess(`이메일이 ${result.email} 주소로 변경되었습니다.`);
      await load();
    } catch (error) {
      setEmailError(errorText(error));
    } finally {
      setConfirmBusy(false);
    }
  }

  async function submitPassword(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (passwordBusy) return;
    setPasswordError("");
    if (!oldPassword) {
      setPasswordError("현재 비밀번호를 입력해 주세요.");
      return;
    }
    if (!newPasswordValid(newPassword)) {
      setPasswordError(
        "새 비밀번호는 10자 이상, UTF-8 기준 72바이트 이하여야 합니다.",
      );
      return;
    }
    if (newPassword !== confirmPassword) {
      setPasswordError("새 비밀번호와 확인 값이 일치하지 않습니다.");
      return;
    }
    setPasswordBusy(true);
    try {
      await accountApi.changePassword(oldPassword, newPassword);
      setOldPassword("");
      setNewPassword("");
      setConfirmPassword("");
      // 현재 세션이 서버에서 해제되므로 헤더 사용자 표시를 초기화합니다.
      window.localStorage.removeItem("userName");
      window.dispatchEvent(new Event("logout-success"));
      router.replace("/register/login");
      router.refresh();
    } catch (error) {
      setPasswordError(errorText(error));
    } finally {
      setPasswordBusy(false);
    }
  }

  async function submitPreferences(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (savingPrefs || !savedPreferences) return;
    setPrefError("");
    setPrefSuccess("");
    setSavingPrefs(true);
    try {
      const result = await accountApi.setPreferences(draftPreferences);
      setSavedPreferences(result);
      setDraftPreferences(result);
      setPrefSuccess("수신 동의 설정이 저장되었습니다.");
    } catch (error) {
      setPrefError(errorText(error));
    } finally {
      setSavingPrefs(false);
    }
  }

  const dirtyPrefs =
    savedPreferences &&
    (savedPreferences.mailAgreed !== draftPreferences.mailAgreed ||
      savedPreferences.snsAgreed !== draftPreferences.snsAgreed);

  return (
    <M.Root>
      <M.Hero>
        <M.HeroInner>
          <M.Eyebrow>PRIVATE MEMBERSHIP — AHNS</M.Eyebrow>
          <M.HeroTitle>
            Account <em>Settings.</em>
          </M.HeroTitle>
          <M.HeroDescription>
            회원님의 소중한 정보와 계정 보안을 관리하는 공간입니다.
          </M.HeroDescription>
        </M.HeroInner>
      </M.Hero>
      <M.MainGrid>
        <M.Sidebar>
          <M.SidebarEyebrow>PRIVATE MEMBERSHIP</M.SidebarEyebrow>
          <M.SidebarHeading>My AHNS</M.SidebarHeading>
          <M.SidebarDescription>
            나를 위한 기록과 일정을
            <br /> 한곳에서 확인하세요.
          </M.SidebarDescription>
          <M.SideNav aria-label="마이페이지 메뉴">
            {menus.map((item) => (
              <M.SideLink
                key={item.href}
                href={item.href}
                $active={item.href === "/mypage/accountsettings"}
                aria-current={
                  item.href === "/mypage/accountsettings" ? "page" : undefined
                }
              >
                {item.label}
              </M.SideLink>
            ))}
          </M.SideNav>
        </M.Sidebar>

        <M.Content>
          <S.Intro>
            <S.IntroEyebrow>ACCOUNT MANAGEMENT / 01</S.IntroEyebrow>
            <S.IntroHeading>나의 정보를 안전하게.</S.IntroHeading>
            <S.IntroDescription>
              회원정보, 비밀번호, 수신 동의를 필요한 때에 직접 관리할 수
              있습니다.
            </S.IntroDescription>
          </S.Intro>
          <S.Tabs role="tablist" aria-label="계정 설정 메뉴">
            {(
              [
                ["profile", "기본정보 · 이메일"],
                ["password", "비밀번호 변경"],
                ["preferences", "수신 동의"],
              ] as const
            ).map(([key, label]) => (
              <S.Tab
                key={key}
                type="button"
                role="tab"
                $active={tab === key}
                aria-selected={tab === key}
                onClick={() => setTab(key)}
              >
                {label}
              </S.Tab>
            ))}
          </S.Tabs>
          {loading ? (
            <S.Panel role="status">회원 정보를 불러오고 있습니다...</S.Panel>
          ) : loadError ? (
            <S.Panel>
              <S.Alert $error role="alert">
                {loadError}
              </S.Alert>
              <M.ButtonRow>
                <M.PlainButton
                  type="button"
                  onClick={() => {
                    void load();
                  }}
                >
                  다시 시도
                </M.PlainButton>
                {(!profile || loadError.includes("로그인")) && (
                  <M.PrimaryLink href="/register/login">
                    로그인하기
                  </M.PrimaryLink>
                )}
              </M.ButtonRow>
            </S.Panel>
          ) : (
            <>
              {tab === "profile" && (
                <>
                  <S.Panel>
                    <S.SectionEyebrow>
                      01 / PERSONAL INFORMATION
                    </S.SectionEyebrow>
                    <S.SectionTitle>기본 정보</S.SectionTitle>
                    <S.SectionDescription>
                      이름과 휴대전화 변경은 명의 확인 서비스 도입 후
                      제공됩니다.
                    </S.SectionDescription>
                    <div>
                      <S.InfoRow>
                        <S.InfoName>아이디</S.InfoName>
                        <S.InfoContent>
                          {profile?.userId || "—"} <S.Micro>변경 불가</S.Micro>
                        </S.InfoContent>
                      </S.InfoRow>
                      <S.InfoRow>
                        <S.InfoName>이름</S.InfoName>
                        <S.InfoContent>
                          {profile?.name || "—"}{" "}
                          <S.Micro>본인확인 필요 · 준비 중</S.Micro>
                        </S.InfoContent>
                      </S.InfoRow>
                      <S.InfoRow>
                        <S.InfoName>휴대전화</S.InfoName>
                        <S.InfoContent>
                          {profile?.phone || "—"}{" "}
                          <S.Micro>본인확인 필요 · 준비 중</S.Micro>
                        </S.InfoContent>
                      </S.InfoRow>
                      <S.InfoRow>
                        <S.InfoName>현재 이메일</S.InfoName>
                        <S.InfoContent>
                          {profile?.email || "미등록"}
                        </S.InfoContent>
                      </S.InfoRow>
                      <S.InfoRow>
                        <S.InfoName>가입일</S.InfoName>
                        <S.InfoContent>
                          {showDate(profile?.joinedAt)}
                        </S.InfoContent>
                      </S.InfoRow>
                    </div>
                    <S.Note>
                      개명 또는 휴대전화 명의 변경은 향후 PASS 등 본인확인
                      서비스 연동 후 지원됩니다. 현재는 계정정보를 임의로 수정할
                      수 없습니다.
                    </S.Note>
                  </S.Panel>
                  <S.Panel>
                    <S.SectionEyebrow>02 / EMAIL VERIFICATION</S.SectionEyebrow>
                    <S.SectionTitle>이메일 변경</S.SectionTitle>
                    <S.SectionDescription>
                      현재 비밀번호를 확인한 후 새 이메일로 전송된 1회용 링크를
                      통해 변경합니다.
                    </S.SectionDescription>
                    {confirmToken && (
                      <S.Alert role="status">
                        새 이메일 인증 링크가 확인되었습니다. 아래 버튼을 눌러
                        최종 변경을 확정하세요.
                        <S.Actions>
                          <S.Primary
                            type="button"
                            onClick={() => {
                              void confirmEmail();
                            }}
                            disabled={confirmBusy}
                          >
                            {confirmBusy
                              ? "인증 확인 중..."
                              : "이메일 변경 확정하기"}
                          </S.Primary>
                        </S.Actions>
                      </S.Alert>
                    )}
                    {emailError && (
                      <S.Alert $error role="alert">
                        {emailError}
                      </S.Alert>
                    )}
                    {emailSuccess && (
                      <S.Alert role="status">{emailSuccess}</S.Alert>
                    )}
                    <form onSubmit={submitEmail}>
                      <S.FieldGrid>
                        <S.Field $full>
                          <S.FieldLabel htmlFor="as-email">
                            새 이메일 주소
                          </S.FieldLabel>
                          <S.TextInput
                            id="as-email"
                            type="email"
                            placeholder="new-email@example.com"
                            value={newEmail}
                            onChange={(e) => setNewEmail(e.target.value)}
                            autoComplete="email"
                            maxLength={100}
                            required
                            disabled={emailBusy}
                          />
                        </S.Field>
                        <S.Field $full>
                          <S.FieldLabel htmlFor="as-email-pw">
                            현재 비밀번호
                          </S.FieldLabel>
                          <S.TextInput
                            id="as-email-pw"
                            type="password"
                            value={currentEmailPassword}
                            onChange={(e) =>
                              setCurrentEmailPassword(e.target.value)
                            }
                            autoComplete="current-password"
                            required
                            disabled={emailBusy}
                          />
                        </S.Field>
                      </S.FieldGrid>
                      <S.Actions>
                        <S.Primary type="submit" disabled={emailBusy}>
                          {emailBusy
                            ? "발송 중..."
                            : "새 이메일로 인증 링크 보내기 ↗"}
                        </S.Primary>
                      </S.Actions>
                    </form>
                    <S.Note>
                      인증 링크는 발급 후 15분간 유효하며 1회만 사용할 수
                      있습니다. 링크를 열어도 변경 확정 전에는 기존 이메일이
                      유지됩니다.
                    </S.Note>
                  </S.Panel>
                </>
              )}

              {tab === "password" && (
                <S.Panel>
                  <S.SectionEyebrow>03 / ACCOUNT SECURITY</S.SectionEyebrow>
                  <S.SectionTitle>비밀번호 변경</S.SectionTitle>
                  <S.SectionDescription>
                    현재 비밀번호가 확인되어야 새 비밀번호를 저장할 수 있습니다.
                    변경 후 다시 로그인해야 합니다.
                  </S.SectionDescription>
                  {passwordError && (
                    <S.Alert $error role="alert">
                      {passwordError}
                    </S.Alert>
                  )}
                  <form onSubmit={submitPassword}>
                    <S.FieldGrid>
                      <S.Field $full>
                        <S.FieldLabel htmlFor="as-current-password">
                          현재 비밀번호
                        </S.FieldLabel>
                        <S.TextInput
                          id="as-current-password"
                          type="password"
                          autoComplete="current-password"
                          required
                          value={oldPassword}
                          onChange={(e) => setOldPassword(e.target.value)}
                          disabled={passwordBusy}
                        />
                      </S.Field>
                      <S.Field>
                        <S.FieldLabel htmlFor="as-new-password">
                          새 비밀번호
                        </S.FieldLabel>
                        <S.TextInput
                          id="as-new-password"
                          type="password"
                          autoComplete="new-password"
                          minLength={10}
                          required
                          value={newPassword}
                          onChange={(e) => setNewPassword(e.target.value)}
                          disabled={passwordBusy}
                        />
                      </S.Field>
                      <S.Field>
                        <S.FieldLabel htmlFor="as-confirm-password">
                          새 비밀번호 확인
                        </S.FieldLabel>
                        <S.TextInput
                          id="as-confirm-password"
                          type="password"
                          autoComplete="new-password"
                          minLength={10}
                          required
                          value={confirmPassword}
                          onChange={(e) => setConfirmPassword(e.target.value)}
                          disabled={passwordBusy}
                        />
                      </S.Field>
                    </S.FieldGrid>
                    <S.Actions>
                      <S.Primary type="submit" disabled={passwordBusy}>
                        {passwordBusy ? "변경 중..." : "비밀번호 변경하기 ↗"}
                      </S.Primary>
                    </S.Actions>
                  </form>
                  <S.Note>
                    비밀번호는 10자 이상으로 입력해 주세요. 현재 비밀번호가
                    기억나지 않는다면{" "}
                    <Link href="/find">이메일로 비밀번호 재설정하기 ↗</Link>를
                    이용할 수 있습니다.
                  </S.Note>
                </S.Panel>
              )}

              {tab === "preferences" && (
                <S.Panel>
                  <S.SectionEyebrow>
                    04 / COMMUNICATION PREFERENCES
                  </S.SectionEyebrow>
                  <S.SectionTitle>수신 동의 설정</S.SectionTitle>
                  <S.SectionDescription>
                    선택적 소식 수신 여부를 언제든 변경할 수 있습니다. 예약·상담
                    필수 안내는 별도입니다.
                  </S.SectionDescription>
                  {prefError && (
                    <S.Alert $error role="alert">
                      {prefError}
                    </S.Alert>
                  )}
                  {prefSuccess && (
                    <S.Alert role="status">{prefSuccess}</S.Alert>
                  )}
                  <form onSubmit={submitPreferences}>
                    <S.ConsentRow>
                      <div>
                        <S.ConsentName>이메일 소식 수신</S.ConsentName>
                        <S.ConsentDescription>
                          이메일을 통한 이벤트·프로모션 및 병원 소식
                        </S.ConsentDescription>
                      </div>
                      <S.Switch
                        type="checkbox"
                        checked={draftPreferences.mailAgreed}
                        onChange={(e) => {
                          setPrefSuccess("");
                          setDraftPreferences((p) => ({
                            ...p,
                            mailAgreed: e.target.checked,
                          }));
                        }}
                        aria-label="이메일 소식 수신 동의"
                        disabled={savingPrefs}
                      />
                    </S.ConsentRow>
                    <S.ConsentRow>
                      <div>
                        <S.ConsentName>SNS 소식 수신</S.ConsentName>
                        <S.ConsentDescription>
                          SNS 채널을 통한 선택적 병원 소식 수신 동의
                        </S.ConsentDescription>
                      </div>
                      <S.Switch
                        type="checkbox"
                        checked={draftPreferences.snsAgreed}
                        onChange={(e) => {
                          setPrefSuccess("");
                          setDraftPreferences((p) => ({
                            ...p,
                            snsAgreed: e.target.checked,
                          }));
                        }}
                        aria-label="SNS 소식 수신 동의"
                        disabled={savingPrefs}
                      />
                    </S.ConsentRow>
                    <S.Actions>
                      <S.Primary
                        type="submit"
                        disabled={!dirtyPrefs || savingPrefs}
                      >
                        {savingPrefs ? "저장 중..." : "동의 설정 저장하기 ↗"}
                      </S.Primary>
                    </S.Actions>
                  </form>
                  <S.Note>
                    동의 변경 일시와 변경 전·후 값은 서버에 기록됩니다. 서비스가
                    실제로 마케팅 메시지를 발송하는 기능과는 별개입니다.
                  </S.Note>
                </S.Panel>
              )}
            </>
          )}
          <M.Cards>
            <M.CardLink href="/mypage">
              <M.CardNumber>01</M.CardNumber>
              <M.CardTitle>마이페이지 ↗</M.CardTitle>
              <M.CardDescription>
                나의 정보와 방문 일정을 확인하세요.
              </M.CardDescription>
            </M.CardLink>
            <M.CardLink href="/mypage/reservations">
              <M.CardNumber>02</M.CardNumber>
              <M.CardTitle>예약 내역 ↗</M.CardTitle>
              <M.CardDescription>
                예약 내역과 방문 일정을 관리하세요.
              </M.CardDescription>
            </M.CardLink>
          </M.Cards>
        </M.Content>
      </M.MainGrid>
    </M.Root>
  );
}
