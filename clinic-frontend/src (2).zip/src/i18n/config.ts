/** AHNS supported locales. Default URLs remain unchanged in Phase 1. */
export const locales = ["ko", "en", "ja"] as const;
export type AppLocale = (typeof locales)[number];
export const defaultLocale: AppLocale = "ko";
export const localeCookieName = "NEXT_LOCALE";

export function isAppLocale(value: unknown): value is AppLocale {
  return (
    typeof value === "string" && locales.some((locale) => locale === value)
  );
}

/** Maps existing language dropdown values to BCP-47 language codes. */
export function normalizeLocale(value: string): AppLocale | null {
  const text = value.trim().toLowerCase();
  if (["ko", "kr", "korean", "한국어"].includes(text)) return "ko";
  if (["en", "eng", "english", "영어"].includes(text)) return "en";
  if (["ja", "jp", "japanese", "日本語", "일본어"].includes(text)) return "ja";
  return null;
}
