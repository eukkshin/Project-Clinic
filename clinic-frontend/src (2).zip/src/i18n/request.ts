import { getRequestConfig } from "next-intl/server";
import { cookies } from "next/headers";

import en from "../messages/en.json";
import ja from "../messages/ja.json";
import ko from "../messages/ko.json";
import { defaultLocale, isAppLocale, localeCookieName } from "./config";

const dictionaries = { ko, en, ja };

// No [locale] folder or proxy is required for this initial, cookie-based setup.
export default getRequestConfig(async () => {
  const savedLocale = (await cookies()).get(localeCookieName)?.value;
  const locale = isAppLocale(savedLocale) ? savedLocale : defaultLocale;

  return {
    locale,
    messages: dictionaries[locale],
    timeZone: "Asia/Seoul",
  };
});
