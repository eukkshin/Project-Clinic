"use client";

import LanguageDropdown from "@/components/dropdown/LanguageDropdown";

import { useChangeLocale } from "./useChangeLocale";

/**
 * Minimal adapter for the existing AHNS LanguageDropdown UI.
 * This keeps its present styling, transparent state and animation untouched.
 * Replace only Header.tsx's LanguageDropdown import path with this file.
 */
export default function LanguageDropdownI18n({
  transparent = false,
  onChange,
}: {
  transparent?: boolean;
  onChange?: (language: string) => void;
}) {
  const changeLocale = useChangeLocale();
  return (
    <LanguageDropdown
      transparent={transparent}
      onChange={(language) => {
        void changeLocale(String(language))
          .then(() => onChange?.(String(language)))
          .catch((error: unknown) => {
            console.error("AHNS language change failed:", error);
          });
      }}
    />
  );
}
