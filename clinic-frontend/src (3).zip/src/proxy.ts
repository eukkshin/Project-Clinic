import { NextResponse } from "next/server";

import { defaultLocale, isAppLocale, localeCookieName } from "./i18n/config";
import { localizedPath, splitLocalePath } from "./i18n/url";

import type { NextRequest } from "next/server";

export function proxy(request: NextRequest) {
  const currentPath = request.nextUrl.pathname;

  const { locale: urlLocale, pathname: barePath } =
    splitLocalePath(currentPath);

  // ============================================
  // 1. 다국어 접두사가 붙은 관리자/API 경로 처리
  // ============================================

  if (urlLocale && /^\/(admin|api)(?:\/|$)/.test(barePath)) {
    const target = request.nextUrl.clone();
    target.pathname = barePath;

    return NextResponse.redirect(target, 307);
  }

  // ============================================
  // 2. 관리자 인증
  // ============================================

  if (currentPath === "/admin" || currentPath.startsWith("/admin/")) {
    const token = request.cookies.get("admin_token")?.value;

    // 로그인 페이지
    if (currentPath === "/admin" || currentPath === "/admin/login") {
      if (token) {
        return NextResponse.redirect(new URL("/admin/root", request.url));
      }

      return NextResponse.next();
    }

    // 관리자 보호 페이지
    if (!token) {
      return NextResponse.redirect(new URL("/admin", request.url));
    }

    return NextResponse.next();
  }

  // ============================================
  // 3. GET / HEAD 이외 요청 처리
  // ============================================

  if (request.method !== "GET" && request.method !== "HEAD") {
    if (!urlLocale) {
      return NextResponse.next();
    }

    const target = request.nextUrl.clone();
    target.pathname = barePath;

    const headers = new Headers(request.headers);
    headers.set("x-ahns-locale", urlLocale);

    return NextResponse.rewrite(target, {
      request: { headers },
    });
  }

  // ============================================
  // 4. 기본 언어(KO) 접두사 제거
  // ============================================

  if (urlLocale === defaultLocale) {
    const target = request.nextUrl.clone();
    target.pathname = barePath;

    const response = NextResponse.redirect(target, 308);

    response.cookies.set(localeCookieName, defaultLocale, {
      path: "/",
      httpOnly: true,
      sameSite: "lax",
      secure: process.env.NODE_ENV === "production",
      maxAge: 60 * 60 * 24 * 365,
    });

    return response;
  }

  // ============================================
  // 5. URL 언어에 맞춰 내부 Rewrite
  // ============================================

  if (urlLocale) {
    const target = request.nextUrl.clone();
    target.pathname = barePath;

    const headers = new Headers(request.headers);
    headers.set("x-ahns-locale", urlLocale);

    const response = NextResponse.rewrite(target, {
      request: { headers },
    });

    response.cookies.set(localeCookieName, urlLocale, {
      path: "/",
      httpOnly: true,
      sameSite: "lax",
      secure: process.env.NODE_ENV === "production",
      maxAge: 60 * 60 * 24 * 365,
    });

    return response;
  }

  // ============================================
  // 6. 쿠키에 저장된 언어 복원
  // ============================================

  const saved = request.cookies.get(localeCookieName)?.value;

  const locale = isAppLocale(saved) ? saved : defaultLocale;

  if (locale !== defaultLocale) {
    const target = request.nextUrl.clone();

    target.pathname = localizedPath(currentPath, locale);

    return NextResponse.redirect(target, 307);
  }

  // ============================================
  // 7. 한국어 기본 페이지
  // ============================================

  return NextResponse.next();
}

// ============================================
// Proxy 적용 경로
// ============================================

export const config = {
  matcher: [
    // 관리자 페이지
    "/admin/:path*",

    // 일반 페이지 (다국어 적용)
    "/((?!api(?:/|$)|admin(?:/|$)|_next(?:/|$)|_vercel(?:/|$)|.*\\..*).*)",
  ],
};
