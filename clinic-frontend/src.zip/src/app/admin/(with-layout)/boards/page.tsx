"use client";
import axios from "axios";
import React, { useEffect, useState } from "react";
import { FiList, FiPlus, FiSave, FiSettings, FiTrash2 } from "react-icons/fi";

import * as S from "@/styles/admin";
import { Popup } from "@/components/ui/Popup";

// 게시판 데이터 인터페이스
interface BoardData {
  id: number;
  name: string;
  type: string;
  readAuth: string;
  writeAuth: string;
  regDate: string;
}

export default function Board() {
  // 🎯 상태 관리: 등록된 게시판 목록
  const [boardList, setBoardList] = useState<BoardData[]>([]);

  // 🎯 상태 관리: 새 게시판 생성 폼
  const [newBoard, setNewBoard] = useState({
    name: "",
    type: "일반게시판",
    readAuth: "전체",
    writeAuth: "관리자",
  });

  const [isSavePopupOpen, setIsSavePopupOpen] = useState(false);
  const [isAlertPopupOpen, setIsAlertPopupOpen] = useState(false);

  const [isDeletePopupOpen, setIsDeletePopupOpen] = useState(false);
  const [selectedDeleteId, setSelectedDeleteId] = useState<number | null>(null);

  // 💡 화면 렌더링 시 DB에서 목록 불러오기
  useEffect(() => {
    fetchBoards();
  }, []);

  const fetchBoards = async () => {
    try {
      const response = await axios.get(
        "http://localhost:4000/api/admin/boards",
      );
      if (response.data.success) {
        const formatted = response.data.data.map((b: any) => {
          // 날짜를 YYYY-MM-DD 형식으로 자르기
          const dateObj = new Date(b.REG_DATE);
          const formattedDate = !isNaN(dateObj.getTime())
            ? dateObj.toISOString().split("T")[0]
            : "";

          return {
            id: b.BOARD_IDX,
            name: b.NAME,
            type: b.BOARD_TYPE,
            readAuth: b.READ_AUTH,
            writeAuth: b.WRITE_AUTH,
            regDate: formattedDate,
          };
        });
        setBoardList(formatted);
      }
    } catch (error) {
      console.error("게시판 목록 로드 실패:", error);
    }
  };

  // 💡 1. 새 게시판 추가 기능 (서버 전송)
  const handleAddBoard = async () => {
    if (!newBoard.name.trim()) {
      setIsAlertPopupOpen(true);
      return;
    }

    try {
      // 이미지가 없으므로 JSON 형태로 바로 전송
      const response = await axios.post(
        "http://localhost:4000/api/admin/boards",
        newBoard,
      );
      if (response.data.success) {
        setNewBoard({
          name: "",
          type: "일반게시판",
          readAuth: "전체",
          writeAuth: "관리자",
        });
        fetchBoards(); // 목록 새로고침
      }
    } catch (error) {
      alert("게시판 생성에 실패했습니다.");
    }
  };

  // 💡 2. 게시판 삭제 기능
  const handleDeleteClick = (id: number) => {
    setSelectedDeleteId(id);
    setIsDeletePopupOpen(true);
  };

  const confirmDelete = async () => {
    if (selectedDeleteId !== null) {
      try {
        const response = await axios.delete(
          `http://localhost:4000/api/admin/boards/${selectedDeleteId}`,
        );
        if (response.data.success) {
          fetchBoards();
        }
      } catch (error) {
        alert("삭제 중 문제가 발생했습니다.");
      }
    }
    setIsDeletePopupOpen(false);
    setSelectedDeleteId(null);
  };

  // 💡 3. 최종 설정 저장 버튼 기능 (추가/삭제는 이미 실시간으로 DB에 반영되므로, UI 확인용도로 유지)
  const handleSave = () => {
    setIsSavePopupOpen(true);
  };

  return (
    <>
      <S.BoardContainer>
        <S.BoardPageHeader className="admin-page-header">
          <div className="admin-page-title-block">
            <span className="admin-page-eyebrow">CONTENT / COMMUNITY</span>
            <S.BoardPageTitle>게시판 관리</S.BoardPageTitle>
            <p className="admin-page-description">게시판을 생성하고 권한 및 목록을 관리합니다.</p>
          </div>
          <S.BoardSaveButton className="admin-primary-action" onClick={handleSave}>
            <FiSave size={18} /> 설정 저장하기
          </S.BoardSaveButton>
        </S.BoardPageHeader>

        <S.BoardGrid className="admin-page-grid">
          {/* ⚙️ 1. 새 게시판 생성 폼 (좌측) */}
          <S.BoardLeftColumn className="admin-editor-column">
            <S.BoardCard className="admin-panel">
              <S.BoardCardHeader className="admin-panel-head">
                <S.BoardCardTitle>새 게시판 생성</S.BoardCardTitle>
              </S.BoardCardHeader>
              <S.BoardCardBody className="admin-panel-body">
                <S.BoardFormGroup className="admin-form-field">
                  <S.BoardLabel>게시판 이름</S.BoardLabel>
                  <S.BoardInput
                    type="text"
                    placeholder="예: 공지사항, 리얼후기"
                    value={newBoard.name}
                    onChange={(e) =>
                      setNewBoard({ ...newBoard, name: e.target.value })
                    }
                  />
                </S.BoardFormGroup>

                <S.BoardFormGroup className="admin-form-field">
                  <S.BoardLabel>게시판 스킨 (타입)</S.BoardLabel>
                  <S.BoardSelect
                    value={newBoard.type}
                    onChange={(e) =>
                      setNewBoard({ ...newBoard, type: e.target.value })
                    }
                  >
                    <option value="일반게시판">일반 게시판 (리스트형)</option>
                    <option value="갤러리형">갤러리형 (썸네일 위주)</option>
                    <option value="FAQ형">FAQ형 (아코디언)</option>
                  </S.BoardSelect>
                </S.BoardFormGroup>

                <div style={{ display: "flex", gap: "1rem" }}>
                  <S.BoardFormGroup className="admin-form-field" style={{ flex: 1 }}>
                    <S.BoardLabel>읽기 권한</S.BoardLabel>
                    <S.BoardSelect
                      value={newBoard.readAuth}
                      onChange={(e) =>
                        setNewBoard({ ...newBoard, readAuth: e.target.value })
                      }
                    >
                      <option value="전체">전체 (비회원 포함)</option>
                      <option value="회원">회원 전용</option>
                      <option value="관리자">관리자 전용</option>
                    </S.BoardSelect>
                  </S.BoardFormGroup>

                  <S.BoardFormGroup className="admin-form-field" style={{ flex: 1 }}>
                    <S.BoardLabel>쓰기 권한</S.BoardLabel>
                    <S.BoardSelect
                      value={newBoard.writeAuth}
                      onChange={(e) =>
                        setNewBoard({
                          ...newBoard,
                          writeAuth: e.target.value,
                        })
                      }
                    >
                      <option value="전체">전체 (비회원 포함)</option>
                      <option value="회원">회원 전용</option>
                      <option value="관리자">관리자 전용</option>
                    </S.BoardSelect>
                  </S.BoardFormGroup>
                </div>

                <S.BoardAddButton className="admin-outline-action" onClick={handleAddBoard}>
                  <FiPlus size={18} /> 게시판 생성하기
                </S.BoardAddButton>
              </S.BoardCardBody>
            </S.BoardCard>
          </S.BoardLeftColumn>

          {/* 📋 2. 등록된 게시판 목록 (우측) */}
          <S.BoardRightColumn className="admin-record-column">
            <S.BoardCard className="admin-panel" style={{ height: "100%" }}>
              <S.BoardCardHeader className="admin-panel-head">
                <S.BoardCardTitle>
                  운영 중인 게시판 목록 (총 {boardList.length}개)
                </S.BoardCardTitle>
              </S.BoardCardHeader>
              <S.BoardTableWrapper className="admin-table-scroll">
                <S.BoardTable className="admin-data-table">
                  <thead>
                    <tr>
                      <th>게시판명</th>
                      <th>스킨/타입</th>
                      <th>권한 (읽기/쓰기)</th>
                      <th>생성일</th>
                      <th>관리</th>
                    </tr>
                  </thead>
                  <tbody>
                    {boardList.map((board) => (
                      <tr key={board.id}>
                        <td style={{ textAlign: "left" }}>
                          <div
                            style={{
                              display: "flex",
                              alignItems: "center",
                              gap: "0.5rem",
                            }}
                          >
                            <FiList color="#b7b9cc" />
                            <a
                              href={`/board/${board.id}`}
                              target="_blank"
                              rel="noreferrer"
                            >
                              <strong>{board.name}</strong>
                            </a>
                          </div>
                        </td>
                        <td>
                          <S.BoardTypeBadge $type={board.type}>
                            {board.type}
                          </S.BoardTypeBadge>
                        </td>
                        <td>
                          <div
                            style={{ fontSize: "0.85rem", color: "#5a5c69" }}
                          >
                            읽기: <strong>{board.readAuth}</strong> <br />
                            쓰기: <strong>{board.writeAuth}</strong>
                          </div>
                        </td>
                        <td style={{ fontSize: "0.85rem", color: "#858796" }}>
                          {board.regDate}
                        </td>
                        <td>
                          <div
                            style={{
                              display: "flex",
                              justifyContent: "center",
                              gap: "0.5rem",
                            }}
                          >
                            <S.BoardActionBtn className="admin-icon-action" title="게시판 설정">
                              <FiSettings size={15} />
                            </S.BoardActionBtn>
                            <S.BoardDeleteBtn className="admin-delete-action"
                              title="삭제"
                              onClick={() => handleDeleteClick(board.id)}
                            >
                              <FiTrash2 size={15} />
                            </S.BoardDeleteBtn>
                          </div>
                        </td>
                      </tr>
                    ))}
                    {boardList.length === 0 && (
                      <tr>
                        <td colSpan={5} style={{ padding: "3rem 0" }}>
                          등록된 게시판이 없습니다.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </S.BoardTable>
              </S.BoardTableWrapper>
            </S.BoardCard>
          </S.BoardRightColumn>
        </S.BoardGrid>
      </S.BoardContainer>

      <Popup
        isOpen={isSavePopupOpen}
        title="저장 완료"
        onClose={() => setIsSavePopupOpen(false)}
        onConfirm={() => setIsSavePopupOpen(false)}
      >
        게시판 설정이 성공적으로 저장되었습니다.
      </Popup>

      <Popup
        isOpen={isAlertPopupOpen}
        title="입력 오류"
        onClose={() => setIsAlertPopupOpen(false)}
        onConfirm={() => setIsAlertPopupOpen(false)}
      >
        게시판 이름을 입력해주세요.
      </Popup>

      <Popup
        isOpen={isDeletePopupOpen}
        title="게시판 삭제 경고"
        onClose={() => {
          setIsDeletePopupOpen(false);
          setSelectedDeleteId(null);
        }}
        onConfirm={confirmDelete}
      >
        이 게시판을 정말 삭제하시겠습니까? <br />
        <span style={{ color: "#e74a3b", fontSize: "0.9rem" }}>
          게시판 내의 모든 게시물도 함께 삭제됩니다.
        </span>
      </Popup>
    </>
  );
}
